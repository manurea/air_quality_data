set.seed(171219)
#-----------------------------------------------------------------------------------
# Author:       Manuele Reani
# Date:         25/11/2018
# Institution:  The university of Manchester - School of Computer Science
# Object:       Look for ourbound postcode in an itersative manner / recursively 
#-----------------------------------------------------------------------------------

#---------------------------------------------------------------------------------
# FUNCTION:     loadPackages(package.args)
# INPUT:        vector
# OUTPUT:       void
# DESCRIPTION:  Loads required packages.
#                
#---------------------------------------------------------------------------------
loadPackages <- function(package.args)
{ 
  for(i in package.args)
  {
    if(!is.element(i, .packages(all.available = TRUE)))
    {
      cat("\nPackage <", i, "> not found, attempting to add it...")
      install.packages(i)
    }
    library(i, character.only = TRUE)
  }
}
#---------------------------------------------------------------------------------
# FUNCTION:     initialize()
# INPUT:        void
# OUTPUT:       void
# DESCRIPTION:  Set up function for adding packages and other source data
#               
#---------------------------------------------------------------------------------
initialize <- function()
{
  # load packages
  package.args <- c("car","msm", "png","jpeg", "gplots", "dplyr", "plyr","tidyr", 
                    "matrixStats",  "lattice","ggplot2", "gtools", 
                    "dbscan", "stringdist", "utils", "qualV", "stringi", "dplyr", 
                    "stringr", "rjson","lsmeans","multcomp","lme4","nlme","MuMIn",
                    "effsize","heplots","DescTools","irr","reshape","psych","effsize",
                    "ggthemes","ggmap","maps","mapdata")
  loadPackages(package.args)
}

initialize()

# ------- load the new datasets and pre-processing -------------------
# change working dir
setwd("C:/Users/manuele/Desktop/postdoc/brbrNew/cleaned_data") 
app_data <- read.csv(file="app_DF.csv",header=TRUE,sep=",") 
pollen_data <- read.csv(file="pollen_DF2.csv",header=TRUE,sep=",") 
AURN_data <- read.csv(file="AURN_DF.csv",header=TRUE,sep=",") 
# eliminate Mace Head from the df (it is in Ireland)
AURN_data <- AURN_data[AURN_data$Postcode3 != "A",]
weather_data <- read.csv(file="weather_DF.csv",header=TRUE,sep=",") 
# go back to working dir
setwd("C:/Users/manuele/Desktop/postdoc/brbrNew")

# rename date to date.precise 
names(app_data)[2] <- "date.precise"
# create a new column in the app df with simple date 
app_data$Date <- as.Date(app_data$date.precise, format = "%d/%m/%Y")
# rename the pollen df with the capital D for date
names(pollen_data)[2] <- "Date"

# check the classes for date in the 2 dfs
class(app_data$Date)
class(pollen_data$Date)
class(AURN_data$Date)
class(weather_data$Date)

# change the format of the 3 df 
pollen_data$Date <- as.Date(pollen_data$Date)
AURN_data$Date <- as.Date(AURN_data$Date)
weather_data$Date <- as.Date(weather_data$Date)

# -------- load the df with the adiacent_Pc for each Pc ------------
adiacent_Pc <- read.csv(file="PostcodeDF.csv",header=TRUE,sep=",")
# Eliminate Guernsey as it doesn't have a Pc (row 42) # optional:(Isle of Man as it doesn't have APC (row 52),Channel Islandsas it doesn't have APC row(55)
adiacent_Pc <- adiacent_Pc[-42,]
#select only the relevant features
adiacent_Pc <- adiacent_Pc[,c(1,10)]
names(adiacent_Pc) <- c("Postcode3", "APc")

# ---- Clean the data eliminating duplicate, by averaging out -----------
# AURN DF
# I only want the relevant columns in the AURUN df
df1 <- AURN_data[,-c(12,13,14,15)]
# find the duplicate in the AURUN df (there some stations with same Postcode3)
# and average the values for the duplicates (same postoce for more than 1 station)
df1<-aggregate(df1[,c(2:11)],
               by=list(Date=df1$Date,Postcode3=df1$Postcode3),
               data=df1,FUN=mean,na.rm=TRUE)

# POLLEN DF
# I only want the relevant columns in the pollen df
df2 <- pollen_data[,-c(1,15,16,17)]
# get the data only for the 2017 and 2018
df2 <- subset(df2, format(as.Date(Date),"%Y")==2017 | 
                     format(as.Date(Date),"%Y")==2018)
# find the duplicate in the polle df (there some stations with same Postcode3)
# and average the values for the duplicates (same postcode for more than 1 station)
df2<-aggregate(df2[,c(2:13)],
               by=list(Date=df2$Date,Postcode3=df2$Postcode3),
               data=df2,FUN=mean,na.rm=TRUE)
# NBB: for the pollen data e need to create the DF for all the dates for 2 years
# and replace the NA with 0
# create a Date df with all the dates in order by Pc 
# (the date found in the AURUN DF)
# (the postcode only found in the pollen DF)
dd<- rep(unique(df1$Date),length(unique(df2$Postcode3)))
pp <- sort(rep(unique(df2$Postcode3),length(unique(df1$Date))))
# create a DF with the full range of dates 
df_dates_pollen <- data.frame (Date = dd,
                        Postcode3 = pp,
                        Provare = rep("zio", length(dd)))
df2_temp <- merge(df2, 
                  df_dates_pollen, by =c("Date","Postcode3"),all.x = T, all.y = T)
df2_temp <- df2_temp[ , names(df2_temp) != "Provare"]
# substitute the NA with 0
df2_temp[is.na(df2_temp)] <- 0
# checks
#length(unique(df2$Date))
#length(unique(df2_temp$Date))
#sum(is.na(df2))
#sum(is.na(df2_temp))
df2 <- df2_temp

# WEATHER DF
# I only want the relevant columns in the weather df
df3 <- weather_data[,-c(1,10,11,12,13)]
# find the duplicate in the weather df (there some stations with same Postcode3)
# and average the values for the duplicates (same postoce for more than 1 station)
df3<-aggregate(df3[,c(2:8)],
               by=list(Date=df3$Date,Postcode3=df3$Postcode3),
               data=df3,FUN=mean,na.rm=TRUE)

# tests to check disparities (e.g., postcode without the full date range)
#nrows <- nrow(Total_DF) 
#DF_xxx <- Total_DF
#(nrows/2)/365 == length(unique(DF_xxx$Postcode3))

# -------- create a Pc/Date df with all the dates in order by Pc -------------
ddd<- rep(unique(df1$Date),length(unique(adiacent_Pc$Postcode3)))
ppp <- sort(rep(unique(adiacent_Pc$Postcode3),length(unique(df1$Date))))
# create a DF with the full range of dates 
df_dates <- data.frame (Date = ddd,
                        Postcode3 = ppp,
                        Provare = rep("zio", length(ddd)))

# ----------------- Merging ------------------------------------------------
# merge each new feature df together with the Pc/Date df 
Total_DF1 <- merge(df1, 
                  df_dates, by =c("Date","Postcode3"),all.x = T, all.y = T)
Total_DF1 <- Total_DF1[ , names(Total_DF1) != "Provare"]

Total_DF2 <- merge(df2, 
                   df_dates, by =c("Date","Postcode3"),all.x = T, all.y = T)
Total_DF2 <- Total_DF2[ , names(Total_DF2) != "Provare"]

Total_DF3 <- merge(df3, 
                   df_dates, by =c("Date","Postcode3"),all.x = T, all.y = T)
Total_DF3 <- Total_DF3[ , names(Total_DF3) != "Provare"]

# merge the 3 feature df together 
Total_DF <- merge(Total_DF1, 
                   Total_DF2, by =c("Date","Postcode3"),all.x = T, all.y = T)
Total_DF <- merge(Total_DF, 
                  Total_DF3, by =c("Date","Postcode3"),all.x = T, all.y = T)

# merge the total df together with the adiacent pc ~~~~~~~~~~~~~~~~~~~~~~~~~~
feature_DF <- merge(Total_DF, 
                    adiacent_Pc, by ="Postcode3",all.x = T, all.y = T)

# ------- add rings columns ------------------------------------------------- 
# add the colums to the app df with the pollen name and the rings for each pollen
for(feature in names(feature_DF[3:31])){
  # create a new column with rings for that feature
  feature_DF[[paste0("rings_", feature)]] <- rep(NA, nrow(feature_DF))
}

## Look at those locations (Pc) where all the data for a feature (a column) are NA.
## Those are the locations idicating lack of stations, 
## or lack of specific measure for that station.
## Place a lable (e.g. the number 100,000,000) for each row in those colums.
## These identify the target where the data needs to be populated.

# ------------ look for location without station, or without instrument ----------- 
# to measure a possible metric and place 100,000,000
for(Pc in unique(feature_DF$Postcode3)){
  df <- feature_DF[feature_DF$Postcode3==Pc,]
  for(feature in names(feature_DF[3:31])){
    if(all(is.na(df[feature]))){
      feature_DF[feature_DF$Postcode3 == Pc,][feature] <- 100000000
    }
  }
}

# -------- convert Postcode3 and APc from factor to character ------------- 
feature_DF$Postcode3 <- as.character(feature_DF$Postcode3)
feature_DF$APc <- as.character(feature_DF$APc)




## In those location with 100,000,000 update with the surrounding average 
## and record the rings.
## Leave the other columns with NA, as we need to do the imputation 
## for missing values later on.
################# I am running it on another file ##########################################################
# recur_pc_main > parte_1 > parte_2
# this returns target_DF
############################################################################################################



# eliminate from te DF the postcode where there is no data 
AQ_DF <- target_DF[target_DF$Postcode3 != 'JE',]
AQ_DF <-AQ_DF[AQ_DF$Postcode3 != 'IM',]


# -------------- Clean the DAQI --------------------
# by region
DAQI_df <- read.csv(file="DAQI_Regional.csv",header=TRUE,sep=",") 
# get the average value for the 4 resgions of scotland 
# and the 2 regions of wales, and store these into two new columns
# called Scotland and Wales
DAQI_df$Scotland <- rowMeans(DAQI_df[c('Central.Scotland', 
                                       'Highland',
                                       'North.East.Scotland',
                                       'Scottish.Borders')], na.rm=TRUE)
DAQI_df$Wales <- rowMeans(DAQI_df[c('North.Wales', 
                                       'South.Wales')], na.rm=TRUE)
# round the values
DAQI_df$Scotland <- round(DAQI_df$Scotland,0)
DAQI_df$Wales <- round(DAQI_df$Wales,0)
# elinate the colums with areas of scotland and wales
drops <- c('Central.Scotland', 
           'Highland',
           'North.East.Scotland',
           'Scottish.Borders',
           'North.Wales', 
           'South.Wales')
DAQI_df <- DAQI_df[ , !(names(DAQI_df) %in% drops)]

# convert this wide df to long
DAQI_df_long <- gather(DAQI_df, Region, DAQI, 
                       East.Midlands:Wales, factor_key=TRUE)
# convert he column Date into real date
DAQI_df_long$Date <- as.Date(DAQI_df_long$Date, format = "%d/%m/%Y")

# by urban area (agglomerate)
DAQI_df2 <- read.csv(file="DAQI_urban_area.csv",header=TRUE,sep=",") 
# convert this wide df to long
DAQI_df_long2 <- gather(DAQI_df2, Urban.area, DAQI, 
                       2:17, factor_key=TRUE)
# convert he column Date into real date
DAQI_df_long2$Date <- as.Date(DAQI_df_long2$Date, format = "%d/%m/%Y")

# now we need to map the 2 dfs with the Pc df
map_pc_df<- read.csv(file="PC_region_urban_area.csv",header=TRUE, sep=",",
                     na.strings=c(""," ","NA"))

# create a target df
ddd<- rep(unique(DAQI_df_long2$Date),length(unique(map_pc_df$Pc)))
ppp <- sort(rep(unique(map_pc_df$Pc),length(unique(DAQI_df_long2$Date))))
# create a DF with the full range of dates 
DAQI_target <- data.frame (Date = ddd,
                        Postcode3 = ppp,
                        DAQI = rep(NA, length(ddd)))

# Fill in DAQI_target$DAQI by looking at conditions in map_pc_df
# by using either DAQI_df_long or DAQI_df_long2
for(date in (as.list(unique(DAQI_target$Date)))){ # NBB loop over dates
  date <- date[[1]][1] # NBB get the date match
  for(Pc in unique(DAQI_target$Postcode3)){
    # look over map_pc_df$Urban.Area
    if(!is.na(map_pc_df[map_pc_df$Pc == Pc, ]$Urban.Area)){ # if the mapping by urban area exists
      # use DAQI_df_long2
      # 1) get the urb_area_name
      urb_area_name <- as.character(map_pc_df[map_pc_df$Pc == Pc, ]$Urban.Area)
      # 2) substitute NA with the actual value
      DAQI_target[DAQI_target$Date == date & 
                    DAQI_target$Postcode3 == Pc, ]$DAQI <- 
        DAQI_df_long2[DAQI_df_long2$Date == date &
                        DAQI_df_long2$Urban.area == urb_area_name,]$DAQI
    }else{ # if the mapping by urban area does not exist
      # use DAQI_df_long
      # 1) get the reagion_name
      reagion_name <- as.character(map_pc_df[map_pc_df$Pc == Pc, ]$Region)
      # 2) substitute NA with the actual value
      DAQI_target[DAQI_target$Date == date & 
                    DAQI_target$Postcode3 == Pc, ]$DAQI <- 
        DAQI_df_long[DAQI_df_long$Date == date &
                        DAQI_df_long$Region == reagion_name,]$DAQI
    }
  }
}

# ----------- map the DAQI_target with the complete AQ_DF ------------
# create the column DAQI
AQ_DF$DAQI <- rep(NA, nrow(AQ_DF))

# replace the NA with the actual value
for(date in (as.list(unique(AQ_DF$Date)))){ # NBB loop over dates
  date <- date[[1]][1] # NBB get the date match
  for(Pc in unique(AQ_DF$Postcode3)){
    AQ_DF[AQ_DF$Date == date &
            AQ_DF$Postcode3 == Pc, ]$DAQI <- 
      DAQI_target[DAQI_target$Date == date &
                    DAQI_target$Postcode3 == Pc, ]$DAQI
  }
}
# save this as the fina air quality df
#write.csv(AQ_DF, file = "AQ_DF.csv", row.names=F)

# -------------  Final fixes ----------------------------------------- 
## Also the rings of these latter location with NA in the feature 
## need to be changed from NA to 0, 
## because there is a station there, 
## it just failed to capture data that day.
# change working dir
setwd("C:/Users/manuele/Desktop/postdoc/brbrNew/cleaned_data") 
AQ_DF <- read.csv(file="AQ_DF.csv",header=TRUE,sep=",") 
# go back to working dir
setwd("C:/Users/manuele/Desktop/postdoc/brbrNew")

# replace NA in rings with 0 (33, 61)
AQ_DF[,33:61][is.na(AQ_DF[,33:61])] <- 0
#write.csv(AQ_DF, file = "AQ_DF2.0.csv", row.names=F)

# --------- AQ_DF + app_data = AQ_app_DF -----------------------
# Then, merge this AQ DF with the App DF, 
# keeping the data only for the App DF.
# app_data <- merge(app_data, df..., by = c("Date","Postcode3"), all.x = T) ??????
# Be careful for postcode BT (and IM), which were not considered in the recursion
# subset by 2017/2018 only
app_data_17_18 <- subset(app_data, format(as.Date(Date),"%Y")!=2019)
AQ_app_DF <- merge(app_data_17_18, AQ_DF, by = c("Date","Postcode3"), all.x = T)
#View(AQ_app_DF[AQ_app_DF$Postcode3=='BT',])
#write.csv(AQ_app_DF, file = "AQ_app_DF.csv", row.names=F)

