# get the full list of unique valid Pc
Full_Pc_list <- unique(feature_DF$Postcode3)
# The postcode BT and IM do not have adiacent PC, so eliminate from the list 
Full_Pc_list <- Full_Pc_list[Full_Pc_list != "BT"]
Full_Pc_list <- Full_Pc_list[Full_Pc_list != "IM"]
# The postcode JE has as an adiacent PC an inexistent Pc (GY), so eliminate from the list 
Full_Pc_list <- Full_Pc_list[Full_Pc_list != "JE"]

target_DF <- feature_DF
# ---------- Run the recursive analysis ----------------------------------------- 
for(feature in names(feature_DF[3:31])){ 
  for(date in (as.list(unique(feature_DF$Date)))){ # NBB loop over dates
    date <- date[[1]][1] # NBB get the date match
    for(Pc in Full_Pc_list){
      rings <- 0
      # get the value matching feature, date and Pc
      new_value <- feature_DF[feature_DF$Date == date & 
                                feature_DF$Postcode3 == Pc,][[feature]]
      if(is.na(new_value)){# check if new_value is na
        next# move on the to the next Pc 
      }
      if(new_value != 100000000){ # is new value of interest
        next# move on to the next Pc 
      }
      # we found a Pc that needs help
      # first define a black_list to avoid infinite loops 
      black_list <- NULL
      
      # ----------------------------- cicle 1 (Pc) ---------------------------
      # increase the rings value by 1
      rings <- rings + 1
      # append the current Pc to the black_list
      black_list <- append(black_list,Pc)
      # call the outer_APc_list and apply it to only one Pc
      APc_list <- outer_APc_list(Pc,black_list,feature_DF) ################# function call 
      if(length(APc_list) == 0){ # is APc_list empty
        # store NaN as value
        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
        print('got an NA and finished the surrounding') #???
        print(paste0("rings ", rings))
        print(Pc) #???
        print(date) #???
        print(feature) #???
        next
      }else{# if APc_list is not empty
        inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
        if(!is.na(inner_value)){# check if inner_value is a valid number
          # store the value and rings
          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
          next# move on the to the next Pc 
        }
        # if inner_value is a NA 
        # ----------------------------- cicle 2 ---------------------------
        # increase the rings value by 1
        rings <- rings + 1
        # append the previous APc_list to the black_list
        black_list <- append(black_list,APc_list)
        # call the outer_APc_list and apply it to the APc_list
        APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
        if(length(APc_list) == 0){ # is APc_list empty
          # store NaN as value
          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
          print('got an NA and finished the surrounding') #???
          print(paste0("rings ", rings))
          print(Pc) #???
          print(date) #???
          print(feature) #???
          next
        }else{# if APc_list is not empty
          inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
          if(!is.na(inner_value)){# check if inner_value is a valid number
            # store the value and rings
            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
            next# move on the to the next Pc 
          }
          # if inner_value is a NA
          # ----------------------------- cicle 3 ---------------------------
          # increase the rings value by 1
          rings <- rings + 1
          # append the previous APc_list to the black_list
          black_list <- append(black_list,APc_list)
          # call the outer_APc_list and apply it to the APc_list
          APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
          if(length(APc_list) == 0){ # is APc_list empty
            # store NaN as value
            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
            print('got an NA and finished the surrounding') #???
            print(paste0("rings ", rings))
            print(Pc) #???
            print(date) #???
            print(feature) #???
            next
          }else{# if APc_list is not empty
            inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
            if(!is.na(inner_value)){# check if inner_value is a valid number
              # store the value and rings
              target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
              target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
              next# move on the to the next Pc 
            }
            # if inner_value is a NA
            # ----------------------------- cicle 4 ---------------------------
            # increase the rings value by 1
            rings <- rings + 1
            # append the previous APc_list to the black_list
            black_list <- append(black_list,APc_list)
            # call the outer_APc_list and apply it to the APc_list
            APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
            if(length(APc_list) == 0){ # is APc_list empty
              # store NaN as value
              target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
              target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
              print('got an NA and finished the surrounding') #???
              print(paste0("rings ", rings))
              print(Pc) #???
              print(date) #???
              print(feature) #???
              next
            }else{# if APc_list is not empty
              inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
              if(!is.na(inner_value)){# check if inner_value is a valid number
                # store the value and rings
                target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                next# move on the to the next Pc 
              }
              # if inner_value is a NA
              # ----------------------------- cicle 5 ---------------------------
              # increase the rings value by 1
              rings <- rings + 1
              # append the previous APc_list to the black_list
              black_list <- append(black_list,APc_list)
              # call the outer_APc_list and apply it to the APc_list
              APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
              if(length(APc_list) == 0){ # is APc_list empty
                # store NaN as value
                target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                print('got an NA and finished the surrounding') #???
                print(paste0("rings ", rings))
                print(Pc) #???
                print(date) #???
                print(feature) #???
                next
              }else{# if APc_list is not empty
                inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                if(!is.na(inner_value)){# check if inner_value is a valid number
                  # store the value and rings
                  target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                  target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                  next# move on the to the next Pc 
                }
                # if inner_value is a NA
                # ----------------------------- cicle 6 ---------------------------
                # increase the rings value by 1
                rings <- rings + 1
                # append the previous APc_list to the black_list
                black_list <- append(black_list,APc_list)
                # call the outer_APc_list and apply it to the APc_list
                APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
                if(length(APc_list) == 0){ # is APc_list empty
                  # store NaN as value
                  target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                  target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                  print('got an NA and finished the surrounding') #???
                  print(paste0("rings ", rings))
                  print(Pc) #???
                  print(date) #???
                  print(feature) #???
                  next
                }else{# if APc_list is not empty
                  inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                  if(!is.na(inner_value)){# check if inner_value is a valid number
                    # store the value and rings
                    target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                    target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                    next# move on the to the next Pc 
                  }
                  # if inner_value is a NA
                  # ----------------------------- cicle 7 ---------------------------
                  # increase the rings value by 1
                  rings <- rings + 1
                  # append the previous APc_list to the black_list
                  black_list <- append(black_list,APc_list)
                  # call the outer_APc_list and apply it to the APc_list
                  APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
                  if(length(APc_list) == 0){ # is APc_list empty
                    # store NaN as value
                    target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                    target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                    print('got an NA and finished the surrounding') #???
                    print(paste0("rings ", rings))
                    print(Pc) #???
                    print(date) #???
                    print(feature) #???
                    next
                  }else{# if APc_list is not empty
                    inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                    if(!is.na(inner_value)){# check if inner_value is a valid number
                      # store the value and rings
                      target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                      target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                      next# move on the to the next Pc 
                    }
                    # if inner_value is a NA
                    # ----------------------------- cicle 8 ---------------------------
                    # increase the rings value by 1
                    rings <- rings + 1
                    # append the previous APc_list to the black_list
                    black_list <- append(black_list,APc_list)
                    # call the outer_APc_list and apply it to the APc_list
                    APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
                    if(length(APc_list) == 0){ # is APc_list empty
                      # store NaN as value
                      target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                      target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                      print('got an NA and finished the surrounding') #???
                      print(paste0("rings ", rings))
                      print(Pc) #???
                      print(date) #???
                      print(feature) #???
                      next
                    }else{# if APc_list is not empty
                      inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                      if(!is.na(inner_value)){# check if inner_value is a valid number
                        # store the value and rings
                        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                        next# move on the to the next Pc 
                      }
                      # if inner_value is a NA
                      # ----------------------------- cicle 9 ---------------------------
                      # increase the rings value by 1
                      rings <- rings + 1
                      # append the previous APc_list to the black_list
                      black_list <- append(black_list,APc_list)
                      # call the outer_APc_list and apply it to the APc_list
                      APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
                      if(length(APc_list) == 0){ # is APc_list empty
                        # store NaN as value
                        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                        target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                        print('got an NA and finished the surrounding') #???
                        print(paste0("rings ", rings))
                        print(Pc) #???
                        print(date) #???
                        print(feature) #???
                        next
                      }else{# if APc_list is not empty
                        inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                        if(!is.na(inner_value)){# check if inner_value is a valid number
                          # store the value and rings
                          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                          next# move on the to the next Pc 
                        }
                        # if inner_value is a NA
                        # ----------------------------- cicle 10 ---------------------------
                        # increase the rings value by 1
                        rings <- rings + 1
                        # append the previous APc_list to the black_list
                        black_list <- append(black_list,APc_list)
                        # call the outer_APc_list and apply it to the APc_list
                        APc_list <- outer_APc_list(APc_list,black_list,feature_DF) ################# function call
                        if(length(APc_list) == 0){ # is APc_list empty
                          # store NaN as value
                          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                          target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- 1000
                          print('got an NA and finished the surrounding') #???
                          print(paste0("rings ", rings))
                          print(Pc) #???
                          print(date) #???
                          print(feature) #???
                          next
                        }else{# if APc_list is not empty
                          inner_value <- mean(list_values_APc(APc_list,feature_DF,date,feature), na.rm=TRUE) ################# function call 
                          if(!is.na(inner_value)){# check if inner_value is a valid number
                            # store the value and rings
                            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- inner_value
                            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                            next# move on the to the next Pc 
                          }else{# if after 10 rings the value is still NA
                            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[feature]] <- NaN
                            target_DF[target_DF$Date == date & target_DF$Postcode3 == Pc, ][[paste0("rings_", feature)]] <- rings
                            print('got an NA with rings over 10') #???
                            print(paste0("rings ", rings))
                            print(Pc) #???
                            print(date) #???
                            print(feature) #???
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

# save this tremp df
#write.csv(target_DF, file = "temp_feature_DF2.csv", row.names=F)



