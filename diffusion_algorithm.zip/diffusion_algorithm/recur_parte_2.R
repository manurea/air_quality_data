#------------------------------------------------------------------------------------
# FUNCTION:     list_values_APc()
# INPUT:        APc_list,feature_DF,date,feature
# OUTPUT:       a list of values, one for each APc in the list of APc
# DESCRIPTION:  Loop over list of APs, and store the values in a list
#------------------------------------------------------------------------------------
list_values_APc <- function(APc_list,feature_DF,date,feature){ # add feature_DF=feature_DF;date=date;feature=feature 
  list_values = NULL
  for(Pc in APc_list){
    # get the new value matching feature, date and Pc 
    new_value <- feature_DF[feature_DF$Date == date & 
                              feature_DF$Postcode3 == Pc,][[feature]]
    if(is.na(new_value)){# check if new_value is na
      next
    }
    if(new_value == 100000000){
      next 
    }
    list_values = append(list_values, new_value)
  }
  return(list_values)
}

#------------------------------------------------------------------------------------
# FUNCTION:     outer_list_APc 
# INPUT:        APc_list,black_list,feature_DF
# OUTPUT:       an APc list in the external ring 
# DESCRIPTION:  it returns an external APc list from an inner APc list, - black_list
#------------------------------------------------------------------------------------
outer_APc_list <- function(APc_list,black_list,feature_DF){# add feature_DF=feature_DF
  outer_list<- NULL
  for(Pc in APc_list){
    # Get Temp_APc_list for that Pc, start with the string
    APc_string <- as.character(feature_DF[feature_DF$Postcode3 == Pc,]$APc[1])
    # eliminate all whitespaces from the string just in case 
    APc_string <- gsub(" ", "", APc_string, fixed = TRUE)
    # get a temporaneous APc list by splitting the string to get a list of adiacent Pc 
    Temp_APc_list <- unlist(strsplit(APc_string, "/"))
    # append this to the real list of APc
    outer_list <- append(outer_list,Temp_APc_list)
  }
  #print(outer_list) ##
  #print(black_list) ##
  outer_list <- setdiff(outer_list, black_list)
  #print(outer_list) ##
  return(outer_list)
}
